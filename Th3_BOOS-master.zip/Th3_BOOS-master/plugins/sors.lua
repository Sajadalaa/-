--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY Th3_BOOS                   ▀▄ ▄▀ 
▀▄ ▄▀     BY Th3_BOOS (@Th3_BOOS)    ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY Th3_BOOS          ▀▄ ▄▀   
▀▄ ▄▀          Dev  : المطور               ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]

do

function run(msg, matches)
  return '❣https://github.com/ahm3d97/Th3_BOOS.git \n❣   #المطور :@Th3_BOOS \n'
end

return {
  patterns = {
    "^اصدار"
  }, 
  run = run 
}

end
