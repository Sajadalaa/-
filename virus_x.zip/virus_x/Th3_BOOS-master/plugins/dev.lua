--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY                    ▀▄ ▄▀ 
▀▄ ▄▀     BY Th3_BOOS (@Th3_BOOS)    ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY Th3_BOOS          ▀▄ ▄▀   
▀▄ ▄▀          dev1  : dev                 ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]
do

function run(msg, matches)
return [[

االبوت الذي يعمل على مجوعات السوبر 🔸

يعمل البوت على مجموعات سوبر تصل الى5k عضو 🔷

     ≪تم صنع البوت بواسطة المطور≫
                      『 @s_ssdj @virus_x 』
            🔹#Dev #جودي_and سجاد
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"مطور البوت$"
},
run = run 
}
end
